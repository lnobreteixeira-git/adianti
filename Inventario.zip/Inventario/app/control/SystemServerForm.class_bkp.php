<?php
/**
 * ServerForm Form
 * @author  <Diogo Nobre Teixeira>
 */
class teste extends TStandardForm
{
    protected $form; // form
    
    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();
        parent::setDatabase('inventario');
        parent::setActiveRecord('SystemServer');
        
        // creates the form
        $this->form = new BootstrapFormBuilder('form_Server');
        $this->form->setFormTitle('Servers');
        $id               = new TEntry('id');
        $name             = new TEntry('nomser');
        $name_so          = new TEntry('nomso');
        $amount_cor       = new TEntry('qtdcor');
        $amount_dis       = new TEntry('qtddis');
        $amount_ram       = new TEntry('qtdram');
        $name_environment = new TEntry('nomamb');
        $name_function    = new TEntry('nomfun');
        $type_server      = new TEntry('tipser');
        $datger           = new TEntry('datger');
        
        $id->setEditable(false);
        $id->setSize(100);
        $name->setSize('70%');
        $name_so->setSize('70%');
        $amount_cor->setSize('70%');
        $amount_dis->setSize('70%');
        $amount_ram->setSize('70%');
        $name_environment->setSize('70%');
        $name_function->setSize('70%');
        $type_server->setSize('70%');
        $datger->setSize('70%')
        
        $this->form->addFields([new TLabel('Id:')],[$id]);
        $this->form->addFields([new TLabel('Name:', '#ff0000')],[$name]);
        $this->form->addFields([new TLabel('Name SO:', '#ff0000')],[$name_so]);
        $this->form->addFields([new TLabel('Amount COR:', '#ff0000')],[$amount_cor]);
        $this->form->addFields([new TLabel('Amount DIS:', '#ff0000')],[$amount_dis]);
        $this->form->addFields([new TLabel('Amount RAM:', '#ff0000')],[$amount_ram]);
        $this->form->addFields([new TLabel('Name environment:', '#ff0000')],[$name_environment]);
        $this->form->addFields([new TLabel('Name function:', '#ff0000')],[$name_function]);
        $this->form->addFields([new TLabel('Type Server:', '#ff0000')],[$type_server]);
        $this->form->addFields([new TLabel('Generation Date:', '#ff0000')],[$datger]);

        // create the form actions
        $this->form->addAction('Salvar', new TAction([$this, 'onSave']), 'fa:floppy-o')->addStyleClass('btn-primary');
        $this->form->addAction('Limpar formulário', new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');
        
        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        $container->add(new TXMLBreadCrumb('menu.xml', 'ServerList'));
        $container->add($this->form);
        parent::add($container);
    }
}