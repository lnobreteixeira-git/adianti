<?php
/**
 * ServerForm Form
 * @author  <Diogo Nobre Teixeira>
 */
class ServerForm extends TPage
{
    /*private $form;*/
    protected $form; // form 
    private $formFields = [];
    private static $database = 'inventario';
    private static $activeRecord = 'SystemServer';
    private static $primaryKey = 'ID';
    private static $formName = 'form_Server';
    
    /**
     * Class constructor
     * Creates the page
     */
    public function __construct()
    {
        parent::__construct();

        $this->form = new BootstrapFormBuilder('form_Server');
        $this->form->setFormTitle('Registration of servers');
        $this->form->setFieldSizes('100%');
        $this->form->appendPage('Basic');

        $id               = new TEntry('id');
        $name             = new TEntry('nomser');
        $name_so          = new TEntry('nomso');
        $amount_cor       = new TEntry('qtdcor');
        $amount_dis       = new TEntry('qtddis');
        $amount_ram       = new TEntry('qtdram');
        $name_environment = new TEntry('nomamb');
        $name_function    = new TEntry('nomfun');
        $type_server      = new TCombo('tipser');
        $datger           = new TEntry('datger');

        $type_server->addItems( ['V' => 'Virtual', 'P' => 'Physicist'] );
        $datger->setValue(date("Y-m-d")); 
        
        $row = $this->form->addFields( [ new TLabel('Code'),     $id ],
                                       [ new TLabel('Name'),     $name ],
                                       [ new TLabel('Type Server'),   $type_server ]);
        $row->layout = ['col-sm-2', 'col-sm-6', 'col-sm-2'];
        
        $row = $this->form->addFields( [ new TLabel('Name SO'),  $name_so ],
                                       [ new TLabel('Name environment'),     $name_environment ],
                                       [ new TLabel('Name function'),    $name_function ] );
        $row->layout = ['col-sm-2', 'col-sm-6', 'col-sm-6'];
        
        $subform = new BootstrapFormBuilder;
        $subform->setFieldSizes('100%');
        $subform->setProperty('style', 'border:none');
        
        $subform->appendPage( 'Address data' );
        $row = $subform->addFields( [ new TLabel('Amount COR'),      $amount_cor ],
                                       [ new TLabel('Amount DIS'),   $amount_dis ],
                                       [ new TLabel('Amount RAM'),   $amount_ram ] );
        $row->layout = ['col-sm-6', 'col-sm-2', 'col-sm-4' ];
        
        
        $subform->appendPage( 'Other data' );
        $row = $subform->addFields( [ new TLabel('Generation Date'),  $datger ]);
        $row->layout = ['col-sm-3' ];
          
        $this->form->addContent( [$subform] );
        
        $this->form->addAction('Salvar', new TAction(array($this, 'onSave')), 'far:check-circle green');
        $this->form->addAction('Limpar', new TAction(array($this, 'onClear')), 'far:check-circle green');
        
        // wrap the page content using vertical box
        $vbox = new TVBox;
        $vbox->style = 'width: 100%';
        $vbox->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $vbox->add($this->form);
        parent::add($vbox);
    }
    
    public function onSave($param) 
    {
        try
        {
        $db = self::$database;
        TTransaction::open( $db ); // open a transaction
        $messageAction = null;
        $this->form->validate();
        $object = new SystemServer();
        $data = $this->form->getData();
        $object->fromArray( (array) $data);
        $object->store();

        $data->ID = $object->ID; 
        $this->form->setData($data); // fill form data
        TTransaction::close(); // close the transaction

        new TMessage('info', 'Servidor salvo com sucesso!', $messageAction);

        } catch (Exception $e) {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
       }
    } 
    public function onClear($param) 
    {
        $this->form->clear();
        new TMessage('info', 'Formulario Limpo com Sucesso !'); 
    } 
 
}