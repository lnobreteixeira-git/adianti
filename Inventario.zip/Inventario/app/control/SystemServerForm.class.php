<?php
/**
 * ServerForm Form
 * @author  <Diogo Nobre Teixeira>
 */
class teste extends TPage
{
    protected $form; // form
    
    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();
        parent::setDatabase('inventario');
        parent::setActiveRecord('SystemServer');

        // creates the form
        $this->form = new BootstrapFormBuilder('form_Server');
        $this->form->setFormTitle('Servers');
        $this->form->setFieldSizes('100%');
        $this->form->appendPage('Basic');

        $id               = new TEntry('id');
        $name             = new TEntry('nomser');
        $name_so          = new TEntry('nomso');
        $amount_cor       = new TEntry('qtdcor');
        $amount_dis       = new TEntry('qtddis');
        $amount_ram       = new TEntry('qtdram');
        $name_environment = new TEntry('nomamb');
        $name_function    = new TEntry('nomfun');
        $type_server      = new TCombo('tipser');
        $datger           = new TDate('datger');
        
        $id->setEditable(false);
        $id->setSize(100);
        $name->setSize('70%');
        $name_so->setSize('70%');

        $amount_cor->setSize('70%');
        $amount_dis->setSize('70%');
        $amount_ram->setSize('70%');
        $name_environment->setSize('70%');
        $name_function->setSize('70%');
        $type_server->addItems( ['V' => 'Virtual', 'P' => 'Physicist'] );
        $type_server->setSize('70%');
        $datger->setMask('dd/mm/yyyy');
        $birthdate->setDatabaseMask('yyyy-mm-dd');
        $datger->setSize('70%');
        
        /*
        $this->form->addFields([new TLabel('Id:')],[$id]);
        $this->form->addFields([new TLabel('Name:', '#ff0000')],[$name]);
        $this->form->addFields([new TLabel('Name SO:', '#ff0000')],[$name_so]);
        $this->form->addFields([new TLabel('Amount COR:', '#ff0000')],[$amount_cor]);
        $this->form->addFields([new TLabel('Amount DIS:', '#ff0000')],[$amount_dis]);
        $this->form->addFields([new TLabel('Amount RAM:', '#ff0000')],[$amount_ram]);
        $this->form->addFields([new TLabel('Name environment:', '#ff0000')],[$name_environment]);
        $this->form->addFields([new TLabel('Name function:', '#ff0000')],[$name_function]);
        $this->form->addFields([new TLabel('Type Server:', '#ff0000')],[$type_server]);
        $this->form->addFields([new TLabel('Generation Date:', '#ff0000')],[$datger]);*/
        $row = $this->form->addFields( [ new TLabel('Id'),     $id ],
                                       [ new TLabel('Name'),     $name ],
                                       [ new TLabel('type Server'),   $type_server ],
                                       [ new TLabel('Name SO'),   $name ] );
        $row->layout = ['col-sm-2', 'col-sm-6', 'col-sm-2', 'col-sm-2' ];

        $row = $this->form->addFields( [ new TLabel('Name environment'),   $name_environment ],
                                       [ new TLabel('Name function'),   $name_function ]);
        $row->layout = ['col-sm-6', 'col-sm-6' ];

        
        $subform = new BootstrapFormBuilder;
        $subform->setFieldSizes('100%');
        $subform->setProperty('style', 'border:none');
        
        $subform->appendPage( 'Quantities' );
        $row = $subform->addFields( [ new TLabel('Amount COR'),  $amount_cor ],
                                    [ new TLabel('Amount DIS'),  $amount_dis ],
                                    [ new TLabel('Amount RAM'),  $amount_ram ] );
        $row->layout = ['col-sm-6', 'col-sm-2', 'col-sm-4' ];
        
        $subform->appendPage( 'Other data' );
        $row = $subform->addFields( [ new TLabel('Generation Date'), $datger ] );
        $row->layout = ['col-sm-4'];
        
        $this->form->addContent( [$subform] );
        //$this->form->addAction('Send', new TAction(array($this, 'onSend')), 'far:check-circle green');
        // create the form actions
        $this->form->addAction('Salvar', new TAction([$this, 'onSave']), 'fa:floppy-o')->addStyleClass('btn-primary');
        $this->form->addAction('Limpar formulário', new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');
        
        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        $container->add(new TXMLBreadCrumb('menu.xml', 'ServerList'));
        $container->add($this->form);
        parent::add($container);
   }
}