<?php
class SystemServer extends TRecord
{
    const TABLENAME = 'INV001';
    const PRIMARYKEY= 'id';
    const IDPOLICY =  'max'; // {max, serial} 
    
    /**
     * Constructor method
     * @param $id Primary key to be loaded (optional)
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('nomser');
        parent::addAttribute('nomso');
        parent::addAttribute('qtdcor');
        parent::addAttribute('qtddis');
        parent::addAttribute('qtdram');
        parent::addAttribute('nomamb');
        parent::addAttribute('nomfun');
        parent::addAttribute('tipser');
        parent::addAttribute('datger');
    }
}