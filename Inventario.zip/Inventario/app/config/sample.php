<?php
return [
    'host'  =>  "",
    'port'  =>  "",
    'name'  =>  "",
    'user'  =>  "",
    'pass'  =>  "",
    'type'  =>  "sqlite",
    'prep'  =>  "1"
];
